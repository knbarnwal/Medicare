<?php
	$dbhost = 'localhost';
	$db = 'medical-store';
	$dbtable = 'login';
	$dbuser = 'root';
	$dbpass = 'navin@mca';
?>